package kmeans.hadoop;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class KMeansReducer extends Reducer<IntWritable, Text, IntWritable, Text> {

    public void reduce(IntWritable key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {

        double[] sum = null;
        int count = 0;

        for (Text val : values) {
            String[] features = val.toString().split(",");

            if (sum == null) {
                sum = new double[features.length];
            }

            for (int i = 0; i < features.length; i++) {
                sum[i] += Double.parseDouble(features[i]);
            }
            count++;
        }

        if (count > 0) {
            StringBuilder newCentroid = new StringBuilder();
            for (int i = 0; i < sum.length; i++) {
                newCentroid.append(sum[i] / count);
                if (i < sum.length - 1) newCentroid.append(",");
            }

            context.write(key, new Text(newCentroid.toString()));
        }
    }
}
