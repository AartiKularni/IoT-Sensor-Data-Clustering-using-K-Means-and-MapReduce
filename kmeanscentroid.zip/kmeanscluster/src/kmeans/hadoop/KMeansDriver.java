package kmeans.hadoop;

import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class KMeansDriver {

    public static void main(String[] args) throws Exception {

        // 🛠 Fix winutils.exe issue
        System.setProperty("hadoop.home.dir", "C:/hadoop");

        // ✅ File paths
        String inputPath = "C:/BDA_Project/sensor_data.csv";
        String outputPath = "C:/BDA_Project/iterate8";
        String centroidPath = "file:///C:/BDA_Project/centroids.txt";  // for distributed cache

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "KMeans Clustering");

        job.setJarByClass(KMeansDriver.class);
        job.setMapperClass(KMeansMapper.class);
        job.setReducerClass(KMeansReducer.class);

        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(Text.class);

        // 📦 Add centroids to distributed cache
        job.addCacheFile(new URI(centroidPath));

        FileInputFormat.addInputPath(job, new Path(inputPath));
        FileOutputFormat.setOutputPath(job, new Path(outputPath));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
