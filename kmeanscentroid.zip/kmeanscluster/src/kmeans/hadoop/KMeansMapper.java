package kmeans.hadoop;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.*;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.JobContext;

public class KMeansMapper extends Mapper<LongWritable, Text, IntWritable, Text> {

    private List<double[]> centroids = new ArrayList<>();

    @Override
    protected void setup(Context context) throws IOException {
        // Load centroids from DistributedCache
        URI[] cacheFiles = context.getCacheFiles();
        if (cacheFiles == null || cacheFiles.length == 0) {
            throw new IOException("Centroids file not set in DistributedCache");
        }

        Path centroidPath = new Path(cacheFiles[0].getPath());
        try (BufferedReader reader = new BufferedReader(new FileReader(centroidPath.toString()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.trim().split(",");
                double[] values = new double[tokens.length];
                for (int i = 0; i < tokens.length; i++) {
                    values[i] = Double.parseDouble(tokens[i]);
                }
                centroids.add(values);
            }
        }
    }

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString().trim();

        // Skip header
        if (line.toLowerCase().contains("temperature")) return;

        String[] tokens = line.split(",");
        if (tokens.length != centroids.get(0).length) return;

        double[] point = new double[tokens.length];
        for (int i = 0; i < tokens.length; i++) {
            point[i] = Double.parseDouble(tokens[i]);
        }

        int nearestCluster = 0;
        double minDistance = Double.MAX_VALUE;

        for (int i = 0; i < centroids.size(); i++) {
            double distance = 0;
            double[] centroid = centroids.get(i);
            for (int j = 0; j < centroid.length; j++) {
                distance += Math.pow(point[j] - centroid[j], 2);
            }
            if (distance < minDistance) {
                minDistance = distance;
                nearestCluster = i;
            }
        }

        context.write(new IntWritable(nearestCluster), value);
    }
}
