package cluster.assignment;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.*;
import java.net.URI;
import java.util.ArrayList;

public class ClusterAssignMapper extends Mapper<LongWritable, Text, IntWritable, Text> {

    private final ArrayList<double[]> centroids = new ArrayList<>();

    @Override
    protected void setup(Context context) throws IOException {
        URI[] cacheFiles = context.getCacheFiles();
        BufferedReader reader = new BufferedReader(new FileReader(new File("./centroids.txt")));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] tokens = line.split(",");
            double[] centroid = new double[tokens.length];
            for (int i = 0; i < tokens.length; i++) {
                centroid[i] = Double.parseDouble(tokens[i]);
            }
            centroids.add(centroid);
        }
        reader.close();
    }

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString().trim();
        if (line.isEmpty() || line.toLowerCase().contains("temperature")) return;

        String[] tokens = line.split(",");
        double[] point = new double[tokens.length];
        for (int i = 0; i < tokens.length; i++) {
            point[i] = Double.parseDouble(tokens[i]);
        }

        int nearestCentroidIndex = 0;
        double minDistance = Double.MAX_VALUE;

        for (int i = 0; i < centroids.size(); i++) {
            double distance = 0;
            for (int j = 0; j < point.length; j++) {
                distance += Math.pow(point[j] - centroids.get(i)[j], 2);
            }
            if (distance < minDistance) {
                minDistance = distance;
                nearestCentroidIndex = i;
            }
        }

        context.write(new IntWritable(nearestCentroidIndex), value);
    }
}
